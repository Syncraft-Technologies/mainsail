import{S as r}from"./Viewer-rvJhQYMO.js";const e="kernelBlurVaryingDeclaration",a="varying vec2 sampleCoord{X};";r.IncludesShadersStore[e]=a;
