import{S as r}from"./Viewer-rvJhQYMO.js";const e="kernelBlurVaryingDeclaration",a="varying sampleCoord{X}: vec2f;";r.IncludesShadersStoreWGSL[e]=a;
